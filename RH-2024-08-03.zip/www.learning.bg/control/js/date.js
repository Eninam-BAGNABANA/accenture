
var d=new Date();
dayname= new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
monthname= new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY =dayname[d.getDay()]+"   "+ monthname[d.getMonth()] + " " +d.getDate() + ", " +d.getFullYear();
